Checking the event schemas
==========================

To validate the event schemas, and check the example events, run

   ./check-examples.py
