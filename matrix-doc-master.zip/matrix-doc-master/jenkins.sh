#!/bin/sh

exec ./scripts/test-and-build.sh
